//
//  ATMExpiredActivitiesViewController.swift
//  AscenticTaskManager
//
//  Created by Sanduni Perera on 2/17/18.
//  Copyright © 2018 Sanduni Perera. All rights reserved.
//

import UIKit
import EventKit
import MZFormSheetPresentationController

class ATMExpiredTaskCell: UITableViewCell {
    @IBOutlet weak var lblTask:UILabel?
    @IBOutlet weak var lblAssignmentTitle:UILabel?
    @IBOutlet weak var lblAssignment:UILabel?
    @IBOutlet weak var lblDueDate:UILabel?
    @IBOutlet weak var btnDelete:UIButton?
    @IBOutlet weak var btnEdit:UIButton?
}

class ATMExpiredActivitiesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, AddAssignmentDelegate, AddTaskDelegate {
    
    let eventStore = EKEventStore()
    
    @IBOutlet weak var tableViewExpired:UITableView?
    @IBOutlet weak var imageViewTasks:UIImageView?
    @IBOutlet weak var imageViewAssignments:UIImageView?
    var arrayExpiredTasks : NSArray = NSArray()
    var arrayExpiredAssignments : NSArray = NSArray()
    var type = "assignment"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        imageViewAssignments?.image = UIImage.init(named: "ic_tick.png")
        imageViewTasks?.image = UIImage.init(named: "ic_untick.png")
        arrayExpiredAssignments = getAssignmentInfo()
        arrayExpiredTasks = getTaskInfo()
        tableViewExpired?.reloadData()
    }
    
    @IBAction func onClickDone(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func onClickTask(_ sender: Any) {
        imageViewTasks?.image = UIImage.init(named: "ic_tick.png")
        imageViewAssignments?.image = UIImage.init(named: "ic_untick.png")
        type = "task"
        tableViewExpired?.reloadData()
    }
    
    @IBAction func onClickAssignments(_ sender: Any) {
        imageViewAssignments?.image = UIImage.init(named: "ic_tick.png")
        imageViewTasks?.image = UIImage.init(named: "ic_untick.png")
        type = "assignment"
        tableViewExpired?.reloadData()
    }
    
    //MARK: - UITableView Datasource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (type == "task") {
            if arrayExpiredTasks.count == 0 {
                self.tableViewExpired?.setEmptyMessage("NO OVERDUE TASKS")
            } else {
                self.tableViewExpired?.restore()
            }
            return arrayExpiredTasks.count
        }
        else {
            if arrayExpiredAssignments.count == 0 {
                self.tableViewExpired?.setEmptyMessage("NO OVERDUE ASSIGNMENTS")
            } else {
                self.tableViewExpired?.restore()
            }
            return arrayExpiredAssignments.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        var cell:ATMExpiredTaskCell?
        cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ATMExpiredTaskCell
        
        if (type == "task") {
            let task : Task = arrayExpiredTasks.object(at: (indexPath.row)) as! Task
            let assignment = ATMCoreDataHelper.getAssignment(withId: task.assignment_id!) as Assignment
            
            cell?.lblTask?.text = task.task_name?.uppercased()
            cell?.lblDueDate?.text = task.due_date
            cell?.lblAssignment?.text = assignment.assignment_name
            
            cell?.lblAssignment?.isHidden = false
            cell?.lblAssignmentTitle?.isHidden = false
        }
        else {
            let assignment : Assignment = arrayExpiredAssignments.object(at: (indexPath.row)) as! Assignment
            
            cell?.lblTask?.text = assignment.assignment_name
            cell?.lblDueDate?.text = assignment.due_date
            
            cell?.lblAssignment?.isHidden = true
            cell?.lblAssignmentTitle?.isHidden = true
        }
        
        cell?.btnDelete?.addTarget(self, action: #selector(ATMExpiredActivitiesViewController.onClickDeleteActivity(_:)), for: .touchUpInside)
        cell?.btnEdit?.addTarget(self, action: #selector(ATMExpiredActivitiesViewController.onClickEditActivity(_:)), for: .touchUpInside)
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 135
    }
    
    // Feed arrays
    func getTaskInfo () -> NSMutableArray{
        let arrayExpiredTasks : NSMutableArray = NSMutableArray()
        let arrayTasks = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Task.rawValue)
        
        for task in arrayTasks {
            let taskDueDate = CommonUtils.convertDate((task as! Task).due_date)
            let taskStatus = (task as! Task).task_status
            if ((taskDueDate < Date()) && (taskStatus != "1")) {
                arrayExpiredTasks.add(task)
            }
        }
        return arrayExpiredTasks
    }
    
    func getAssignmentInfo () -> NSMutableArray{
        let arrayExpiredAssignments : NSMutableArray = NSMutableArray()
        let arrayAssignments = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        
        for assignment in arrayAssignments {
            let incompletedTasksArray = ATMCoreDataHelper.getIncompletedTasksForAssignment(withAssignmentId: (assignment as! Assignment).id!)
            let assignmentDueDate = CommonUtils.convertDate((assignment as! Assignment).due_date)
            if (assignmentDueDate < Date() && incompletedTasksArray.count > 0) {
                arrayExpiredAssignments.add(assignment)
            }
        }
        return arrayExpiredAssignments
    }
    
    //MARK - Class delegate methods
    
    func updateDataAfterAddingAssignment() {
        arrayExpiredAssignments = getAssignmentInfo()
        tableViewExpired?.reloadData()
    }
    
    func updateDataAfterAddingTask() {
        arrayExpiredTasks = getTaskInfo()
        tableViewExpired?.reloadData()
    }
    
    //Mark - Tableview button click events
    
    @objc func onClickDeleteActivity(_ sender : UIButton) {
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tableViewExpired)
        let indexPath = self.tableViewExpired?.indexPathForRow(at: buttonPosition)
        
        if (type == "task") {
            let task : Task = arrayExpiredTasks.object(at: (indexPath?.row)!) as! Task
            
            let taskId = task.id
            let taskReminder = task.reminder_identifier
            
            print(taskId ?? "")
            print(taskReminder ?? "")
            
            ATMReminder.removeTaskReminder(store: eventStore, taskReminderID: taskReminder!)
            ATMCoreDataHelper.deleteProfile(dataTable: CommonUtils.DataTables.Task.rawValue, withID:taskId!)
            
            arrayExpiredTasks = getTaskInfo()
            tableViewExpired?.reloadData()
        }
        else {
            let assignment : Assignment = arrayExpiredAssignments.object(at: (indexPath?.row)!) as! Assignment
            
            // Remove assignment , event and reminder
            ATMReminder.removeReminder(store: eventStore, assignmentReminderID: assignment.reminder_identifier!)
            ATMEvent.removeEvent(store: eventStore, assignmentEventID: assignment.event_identifier!)
            ATMCoreDataHelper.deleteProfile(dataTable: CommonUtils.DataTables.Assignment.rawValue, withID:assignment.id!)
            
            // Remove task and reminder
            ATMReminder.removeTaskRemindersofSelectedAssignment(store: eventStore, assignmentID: assignment.id!)
            ATMCoreDataHelper.deleteAllDataTasks(assignmentID: assignment.id!)
            
            arrayExpiredAssignments = getAssignmentInfo()
            tableViewExpired?.reloadData()
        }
    }
    
    @objc func onClickEditActivity(_ sender:UIButton) {
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tableViewExpired)
        let indexPath = self.tableViewExpired?.indexPathForRow(at: buttonPosition)
        
        if (type == "task") {
            let task : Task = arrayExpiredTasks.object(at: (indexPath?.row)!) as! Task
            
            let assignment : Assignment = ATMCoreDataHelper.getAssignment(withId: task.assignment_id!)
            
            // Navigate to edit the task
            let vc:ATMAddTaskViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMAddTaskViewController") as! ATMAddTaskViewController
            vc.delegate = self as AddTaskDelegate
            vc.taskToEdit = task
            vc.isUpdate = true
            vc.assignmentID = assignment.id!
            vc.assignment = assignment
            vc.canEdit = false
            let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
            formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
            self.present(formSheetController, animated: false, completion: nil)
        }
        else {
            let assignment : Assignment = arrayExpiredAssignments.object(at: (indexPath?.row)!) as! Assignment
            
            // Navigate to edit the assignment
            let vc:ATMAddAssignmentViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMAddAssignmentViewController") as! ATMAddAssignmentViewController
            vc.delegate = self
            vc.assignmentToEdit = assignment
            vc.isUpdate = true
            vc.canEdit = false
            let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
            formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
            self.present(formSheetController, animated: false, completion: nil)
        }
    }
}

