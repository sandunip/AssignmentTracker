//
//  ATMCompletedTasksViewController.swift
//  AscenticTaskManager
//
//  Created by Sanduni Perera on 2/14/18.
//  Copyright © 2018 Sanduni Perera. All rights reserved.
//

import UIKit
import EventKit
import MZFormSheetPresentationController

class ATMCompletedTasksViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    let eventStore = EKEventStore()
    
    @IBOutlet weak var tableViewCompleted:UITableView?
    var type = "assignment"
    var currentAssignmentId: String = "0"
    var arrayCompletedTasks : NSArray = NSArray()

    override func viewDidLoad() {
        super.viewDidLoad()

        arrayCompletedTasks = ATMCoreDataHelper.getTasksWith(status: CommonUtils.TaskStatus.Completed.rawValue, assignmentId: currentAssignmentId)
        tableViewCompleted?.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - UITableView Datasource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayCompletedTasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        var cell:ATMTaskCell?
        cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ATMTaskCell
        
        cell?.btnDelete?.addTarget(self, action: #selector(ATMDetailViewController.onClickDeleteAssignmentNotStarted(_:)), for: .touchUpInside)
        
        let task : Task = arrayCompletedTasks.object(at: (indexPath.row)) as! Task
        
        cell?.lblTask?.text = task.task_name?.uppercased()
        
        cell?.btnDelete?.addTarget(self, action: #selector(ATMCompletedTasksViewController.onClickDeleteActivity(_:)), for: .touchUpInside)
        cell?.btnEdit?.addTarget(self, action: #selector(ATMCompletedTasksViewController.onClickEditActivity(_:)), for: .touchUpInside)
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 106
    }
    
    @IBAction func onClickDone(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    //Mark - Tableview button click events
    
    @objc func onClickDeleteActivity(_ sender : UIButton) {
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tableViewCompleted)
        let indexPath = self.tableViewCompleted?.indexPathForRow(at: buttonPosition)
        
        let task : Task = arrayCompletedTasks.object(at: (indexPath?.row)!) as! Task
        
        let taskId = task.id
        let taskReminder = task.reminder_identifier
        
        ATMReminder.removeTaskReminder(store: eventStore, taskReminderID: taskReminder!)
        ATMCoreDataHelper.deleteProfile(dataTable: CommonUtils.DataTables.Task.rawValue, withID:taskId!)
        
        arrayCompletedTasks = ATMCoreDataHelper.getTasksWith(status: CommonUtils.TaskStatus.Completed.rawValue, assignmentId: currentAssignmentId)
        tableViewCompleted?.reloadData()
    }
    
    @objc func onClickEditActivity(_ sender:UIButton) {
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tableViewCompleted)
        let indexPath = self.tableViewCompleted?.indexPathForRow(at: buttonPosition)
        
        let task : Task = arrayCompletedTasks.object(at: (indexPath?.row)!) as! Task
        
        let assignment : Assignment = ATMCoreDataHelper.getAssignment(withId: task.assignment_id!)
        
        // Navigate to edit the task
        let vc:ATMAddTaskViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMAddTaskViewController") as! ATMAddTaskViewController
        vc.taskToEdit = task
        vc.isUpdate = true
        vc.assignmentID = assignment.id!
        vc.assignment = assignment
        vc.canEdit = false
        let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
        formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
        self.present(formSheetController, animated: false, completion: nil)
    }

}
