//
//  CommonUtils.swift
//  AscenticTaskManager
//
//  Created by Sanduni Perera on 2/14/18.
//  Copyright © 2018 Sanduni Perera. All rights reserved.
//

import UIKit

class CommonUtils: NSObject {
    
    static func showMesage (_ messgae:String?){
        let alert:UIAlertView = UIAlertView(title: "Ascentic Task Manager", message: messgae, delegate: nil, cancelButtonTitle: "Okay")
        alert.show()
    }
    
    static func convertDate (_ date:String?) -> Date{
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "US_en")
        formatter.dateFormat = "dd/MM/yyyy"
        let date = formatter.date(from: date!)
        
        return date!
    }
    
    static func convertDateToString (_ date:Date?) -> String{
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "US_en")
        formatter.dateFormat = "dd/MM/yyyy"
        let date = formatter.string(from: date!)
        
        return date
    }

    static func validateNumbersof(textField : UITextField) -> Bool{
        var boolStatus : Bool = true
        let intValue = Int(textField.text!)
        if (intValue == nil){
            boolStatus = false
        }
        return boolStatus
    }
    
    static func validateNumbersOverHundredof(textField : UITextField) -> Bool{
        var boolStatus : Bool = true
        let intValue = Int(textField.text!)
        if (intValue != nil){
            if (intValue! < 101) {
                boolStatus = true
            }
            else {
                boolStatus = false
            }
        }
        else {
            boolStatus = false
        }
        return boolStatus
    }
    
    enum TaskStatus: String {
        case Completed = "1"
        case InProgress = "2"
        case NotStarted = "3"
    }
    
    enum DataTables: String {
        case Assignment = "Assignment"
        case Task = "Task"
    }
}

extension String{
    func dateStringFromFormat (_ fromFormat:String, toFormat:String) -> String{
        let fromFormatter:DateFormatter = DateFormatter()
        fromFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX") as Locale!
        
        fromFormatter.dateFormat = fromFormat
        
        let fromDate:Date? = fromFormatter.date(from: self)
        
        let toFormatter:DateFormatter = DateFormatter()
        toFormatter.dateFormat = toFormat
        
        if let date = fromDate{
            return toFormatter.string(from: date)
        }
        return ""
    }
    
    func dateFromFormat (_ fromFormat:String) -> Date?{
        let fromFormatter:DateFormatter = DateFormatter()
        fromFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX") as Locale!
        fromFormatter.dateFormat = fromFormat
        return fromFormatter.date(from: self)
    }
}

extension UIColor{
    class func getAppThemeColor() -> UIColor{
        return UIColor.init(red: (25.0/255.0), green: (90.0/255.0), blue: (63.0/255.0), alpha: 1)
    }
    
    class func getMasterTableBackgroundColor() -> UIColor{
        return UIColor.init(red: (37.0/255.0), green: (167.0/255.0), blue: (146.0/255.0), alpha: 1)
    }
}

extension UITableView {
    
    func setEmptyMessage(_ message: String) {
        let messageLabel = UILabel(frame: CGRect(x: 0, y: 0, width: self.bounds.size.width, height: 50))
        messageLabel.text = message
        messageLabel.textColor = .black
        messageLabel.numberOfLines = 0;
        messageLabel.textAlignment = .center;
        messageLabel.font = UIFont.systemFont(ofSize: 20)
        messageLabel.sizeToFit()
        messageLabel.layer.borderWidth = 1.0
        messageLabel.layer.borderColor = UIColor.getAppThemeColor().cgColor
        
        self.backgroundView = messageLabel;
        self.separatorStyle = .none;

    }
    
    func restore() {
        self.backgroundView = nil
        self.separatorStyle = .singleLine
    }
}

