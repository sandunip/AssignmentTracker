//
//  ATMDashBoardViewController.swift
//  AscenticTaskManager
//
//  Created by LAYOUTindex on 2/13/18.
//  Copyright © 2018 Sanduni Perera. All rights reserved.
//

import UIKit
import CoreData
import GTProgressBar
import MZFormSheetPresentationController

//class ATMAssignmentCell: UITableViewCell{
//    @IBOutlet weak var lblAssignment:UILabel?
//    @IBOutlet weak var btnDelete:UIButton?
//    @IBOutlet weak var btnEdit:UIButton?
//}

//class ATMTaskCell: UITableViewCell{
//    @IBOutlet weak var lblTask:UILabel?
//    @IBOutlet weak var viewProgress:GTProgressBar?
//    @IBOutlet weak var btnMarkAsCompleted:UIButton?
//    @IBOutlet weak var btnDelete:UIButton?
//    @IBOutlet weak var btnEdit:UIButton?
//}

class ATMDashBoardViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, addAssignmentDelegate {

    @IBOutlet weak var tableViewAssignments:UITableView?
    @IBOutlet weak var tableViewCompleted:UITableView?
    @IBOutlet weak var tableViewInProgress:UITableView?
    @IBOutlet weak var tableViewNotStarted:UITableView?
    
    var arrayAssignments : NSArray = NSArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableViewNotStarted?.tableFooterView = UIView()
        tableViewNotStarted?.backgroundColor = UIColor.clear
        tableViewInProgress?.tableFooterView = UIView()
        tableViewInProgress?.backgroundColor = UIColor.clear
        tableViewCompleted?.tableFooterView = UIView()
        tableViewCompleted?.backgroundColor = UIColor.clear
        tableViewAssignments?.tableFooterView = UIView()
        tableViewAssignments?.backgroundColor = UIColor.clear
        
        arrayAssignments = ATMCoreDataHelper.getInfo()
        self.tableViewAssignments?.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - UITableView Datasource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (tableView == tableViewAssignments) {
            return arrayAssignments.count
        }
        else if (tableView == tableViewCompleted) {
            return 5
        }
        else if (tableView == tableViewInProgress) {
            return 2
        }
        else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        if (tableView == tableViewAssignments) {
            
            var cell:ATMAssignmentCell?
            cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ATMAssignmentCell
            
            cell?.lblAssignment?.text = "Social Studies Task".uppercased()
            
            cell?.btnDelete?.addTarget(self, action: #selector(ATMDashBoardViewController.onClickDeleteAssignment(_:)), for: .touchUpInside)
            cell?.btnEdit?.addTarget(self, action: #selector(ATMDashBoardViewController.onClickEditAssignment(_:)), for: .touchUpInside)
            let assignment : Assignment = arrayAssignments.object(at: (indexPath.row)) as! Assignment
            
            cell?.lblAssignment?.text = assignment.assignment_name
            
            return cell!
        }
        else if (tableView == tableViewCompleted) {
            
            var cell:ATMTaskCell?
            cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ATMTaskCell
            
            cell?.lblTask?.text = "Social Studies Task".uppercased()
            
            return cell!
        }
        else if (tableView == tableViewInProgress) {
            
            var cell:ATMTaskCell?
            cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ATMTaskCell
            
            cell?.lblTask?.text = "Social Studies Task".uppercased()
            
            cell?.viewProgress?.progress = 0.5
            
            return cell!
        }
        else {
            
            var cell:ATMTaskCell?
            cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ATMTaskCell
            
            cell?.lblTask?.text = "Social Studies Task".uppercased()
            
            return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (tableView == tableViewAssignments) {
            
            return 94
        }
        else if (tableView == tableViewCompleted) {
            
            return 106
        }
        else if (tableView == tableViewInProgress) {
            
            return 154
        }
        else {
            
            return 106
        }
    }
    
    @IBAction func onClickAddAssignment(_ sender: Any) {
        let vc:ATMAddAssignmentViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMAddAssignmentViewController") as! ATMAddAssignmentViewController
        vc.delegate = self
        let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
        formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
        self.present(formSheetController, animated: false, completion: nil)
    }
    
    @IBAction func onClickAddTask(_ sender: Any) {
        let navigationController = self.storyboard!.instantiateViewController(withIdentifier: "ATMAddTaskViewController")
        let formSheetController = MZFormSheetPresentationViewController(contentViewController: navigationController)
        formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
        self.present(formSheetController, animated: false, completion: nil)
    }
    
    @IBAction func onClickPreview(_ sender: Any) {
        let navigationController = self.storyboard!.instantiateViewController(withIdentifier: "ATMPreviewViewController")
        let formSheetController = MZFormSheetPresentationViewController(contentViewController: navigationController)
        formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
        self.present(formSheetController, animated: false, completion: nil)
    }
    
    @IBAction func onClickDeleteAllAssignments(_ sender: Any) {
        ATMCoreDataHelper.deleteAllData()
        arrayAssignments = ATMCoreDataHelper.getInfo()
        self.tableViewAssignments?.reloadData()
    }
    
//    //MARK: - Core data functions
//
//    func deleteAllData() {
//        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Assignment")
//        fetchRequest.returnsObjectsAsFaults = false
//
//        do {
//            let results = try context.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>)
//            for managedObject in results
//            {
//                let managedObjectData:NSManagedObject = managedObject as! NSManagedObject
//                context.delete(managedObjectData)
//                do {
//                    try context.save()
//                    print("saved!")
//                } catch let error as NSError  {
//                    print("Could not save \(error), \(error.userInfo)")
//                }
//            }
//        } catch let error as NSError {
//            print("Detele all data in Assignment error : \(error) \(error.userInfo)")
//        }
//    }
//
//    func getInfo () {
//        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Assignment")
//        do {
//            arrayAssignments = try context.fetch(fetchRequest) as NSArray
//            print("all records array count \(arrayAssignments.count)")
//        } catch let error as NSError {
//            print("Could not fetch. \(error), \(error.userInfo)")
//        }
//        self.tableViewAssignments?.reloadData()
//    }
//
//    func deleteProfile(withID: String) {
//        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
//        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Assignment")
//        fetchRequest.predicate = NSPredicate.init(format: "id ==\(withID)")
//        let object = try! context.fetch(fetchRequest)
//        if let result = try? context.fetch(fetchRequest) {
//            for object in result {
//                context.delete(object)
//            }
//            do {
//                try context.save()
//                print("saved!")
//            } catch let error as NSError  {
//                print("Could not save \(error), \(error.userInfo)")
//            }
//        }
//        self.getInfo()
//    }
    
    //MARK: - UITableview Button click actions
    
    @objc func onClickDeleteAssignment(_ sender : UIButton) {
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tableViewAssignments)
        let indexPath = self.tableViewAssignments?.indexPathForRow(at: buttonPosition)
        
        let assignment : Assignment = arrayAssignments.object(at: (indexPath?.row)!) as! Assignment
        
        ATMCoreDataHelper.deleteProfile(withID:assignment.id!)
    }
    
    @objc func onClickEditAssignment(_ sender:UIButton) {
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tableViewAssignments)
        let indexPath = self.tableViewAssignments?.indexPathForRow(at: buttonPosition)
        
        let assignment : Assignment = arrayAssignments.object(at: (indexPath?.row)!) as! Assignment
        
        // Navigate to edit the assignment
        let vc:ATMAddAssignmentViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMAddAssignmentViewController") as! ATMAddAssignmentViewController
        vc.delegate = self
        vc.assignmentToEdit = assignment
        vc.isUpdate = true
        let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
        formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
        self.present(formSheetController, animated: false, completion: nil)
    }

    // MARK: - Add Assignment Delegate

    func updateDataAfterAddingAssignment() {
        arrayAssignments = ATMCoreDataHelper.getInfo()
        self.tableViewAssignments?.reloadData()
    }

}
