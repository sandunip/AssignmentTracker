//
//  ATMAddTaskViewController.swift
//  AscenticTaskManager
//
//  Created by Sanduni Perera on 2/11/18.
//  Copyright © 2018 Sanduni Perera. All rights reserved.
//

import UIKit
import EventKit
import CoreData

protocol AddTaskDelegate: class {
    func updateDataAfterAddingTask()
}

class ATMAddTaskViewController: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource {
    
    weak var delegate: AddTaskDelegate?
    
    @IBOutlet weak var txtTaskName:UITextField?
    @IBOutlet weak var txtStartDate:UITextField?
    @IBOutlet weak var txtDueDate:UITextField?
    @IBOutlet weak var txtReminderDate:UITextField?
    @IBOutlet weak var reminderView:UIView?
    @IBOutlet weak var txtEstimatedDays:UITextField?
    @IBOutlet weak var txtNotes:UITextView?
    @IBOutlet weak var txtCompletedPercentage:UITextField?
    @IBOutlet weak var txtTaskStatus:UITextField?
    @IBOutlet weak var switchReminder:UISwitch?
    
    @IBOutlet weak var viewTaskStatus:UIView?
    @IBOutlet weak var viewPercentage:UIView?
    
    @IBOutlet weak var btnSubmit:UIButton?
    var canEdit : Bool = true
    
    @IBOutlet weak var lblNoofDaysRemaining:UILabel?
    @IBOutlet weak var lblHeading:UILabel?
    
    var arrayTasks: NSArray = NSArray()
    var isUpdate: Bool = false
    var taskToEdit: Task?
    var arrayTaskStatus :NSArray?
    var taskStatus = ""
    var assignmentID = ""
    var assignment : Assignment?
    
    let taskStatusPicker:UIPickerView = UIPickerView()
    let startDatePicker:UIDatePicker = UIDatePicker()
    let dueDatePicker:UIDatePicker = UIDatePicker()
    let reminderDatePicker:UIDatePicker = UIDatePicker()
    
    var reminderIdentifier = ""

    let eventStore = EKEventStore()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtStartDate?.text = CommonUtils.convertDateToString(Date())
//        let actualReminderDate = Calendar.current.date(byAdding: .day, value: -2, to: CommonUtils.convertDate(assignment?.due_date))
//        if (actualReminderDate! < Date()) {
//            txtReminderDate?.text = CommonUtils.convertDateToString(Calendar.current.date(byAdding: .day, value: -2, to: CommonUtils.convertDate(assignment?.due_date)))
//        }
//        else {
//            txtReminderDate?.text = CommonUtils.convertDateToString(Calendar.current.date(byAdding: .day, value: -2, to: CommonUtils.convertDate(assignment?.due_date)))
//        }

        arrayTaskStatus = ["Completed", "In Progress", "Not Started"]
        
        taskStatusPicker.delegate = self
        taskStatusPicker.dataSource = self
        txtTaskStatus?.inputView = taskStatusPicker
        
        startDatePicker.datePickerMode = UIDatePickerMode.date
        startDatePicker.minimumDate = Date()
        startDatePicker.maximumDate = Calendar.current.date(byAdding: .day, value: -1, to: CommonUtils.convertDate(assignment?.due_date))
        startDatePicker.addTarget(self, action: #selector(self.startDateChanged(_:)), for: UIControlEvents.valueChanged)
        txtStartDate?.inputView = startDatePicker
        
        dueDatePicker.datePickerMode = UIDatePickerMode.date
        dueDatePicker.minimumDate = Calendar.current.date(byAdding: .day, value: 1, to: CommonUtils.convertDate(txtStartDate?.text))
        dueDatePicker.maximumDate = CommonUtils.convertDate(assignment?.due_date)
        dueDatePicker.addTarget(self, action: #selector(self.dueDateChanged(_:)), for: UIControlEvents.valueChanged)
        txtDueDate?.inputView = dueDatePicker
        
        reminderDatePicker.datePickerMode = UIDatePickerMode.date
        reminderDatePicker.minimumDate = Calendar.current.date(byAdding: .day, value: 1, to: Date())
        reminderDatePicker.addTarget(self, action: #selector(self.reminderDateChanged(_:)), for: UIControlEvents.valueChanged)
        txtReminderDate?.inputView = reminderDatePicker

        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ATMAddTaskViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
        
        let assignmentName = assignment?.assignment_name
        if (isUpdate) {
            self.assignInfo()
            lblNoofDaysRemaining?.text = self.calculateRemaningdays() + " days remaining"
            lblHeading?.text = "UPDATE TASK TO \(assignmentName!)".uppercased()
            if (txtTaskStatus?.text == "In Progress") {
                viewPercentage?.isHidden = false
            }
            else {
                viewPercentage?.isHidden = true
            }
        }
        else {
            lblNoofDaysRemaining?.text = ""
            lblHeading?.text = "ADD TASK TO \(assignmentName!)".uppercased()
            viewTaskStatus?.isHidden = true
            viewPercentage?.isHidden = true
            txtCompletedPercentage?.text = "0"
        }
        if (!canEdit) {
            btnSubmit?.isHidden = true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @objc func startDateChanged(_ picker:UIDatePicker) {
        txtStartDate?.text = self.getFormattedDate(picker.date)
        dueDatePicker.minimumDate = Calendar.current.date(byAdding: .day, value: 1, to: CommonUtils.convertDate(txtStartDate?.text))
    }
    
    @objc func dueDateChanged(_ picker:UIDatePicker) {
        txtDueDate?.text = self.getFormattedDate(picker.date)
        lblNoofDaysRemaining?.text = self.calculateRemaningdays() + " days remaining"
        
        let reminderDate = CommonUtils.convertDate(txtDueDate?.text)
        txtReminderDate?.text = CommonUtils.convertDateToString(Calendar.current.date(byAdding: .day, value: -1, to: reminderDate))
    }
    
    @objc func reminderDateChanged(_ picker:UIDatePicker) {
        txtReminderDate?.text = self.getFormattedDate(picker.date)
    }
    
    func getFormattedDate (_ date:Date) -> String{
        let dateString:String = date.description
        return dateString.dateStringFromFormat("Y-M-d H-m-s Z", toFormat: "dd/MM/yyyy")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onClickDone(_ sender: Any) {
        validate()
    }
    
    @IBAction func onClickCancel(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    func validate () {
        if (txtTaskName?.text != "") {
            if (txtStartDate?.text != "") {
                if (txtDueDate?.text != "") {
                    if (txtCompletedPercentage?.text != "") {
                        if (CommonUtils.validateNumbersOverHundredof(textField: txtCompletedPercentage!)) {
                            if (CommonUtils.validateNumbersof(textField: txtEstimatedDays!)) {
                                
                                let remainingDays = Int(calculateRemaningdays())!
                                let estimatedDays = Int((txtEstimatedDays?.text)!)!
                                if (remainingDays > estimatedDays) {
                                    
                                    let reminderDate = CommonUtils.convertDate(txtReminderDate?.text)
                                    let dueDate = CommonUtils.convertDate(txtDueDate?.text)
                                    if (reminderDate <= dueDate) {
                                        
                                        if (isUpdate == false) {
                                            self.saveInfo()
                                        }
                                        else {
                                            self.updateInfo()
                                        }
                                    }
                                    else {
                                        CommonUtils.showMesage("Reminder Date should be less or same date with due date!")
                                    }
                                }
                                else {
                                    CommonUtils.showMesage("Estimated days should not exceed number of remaining days!")
                                }
                            }
                            else {
                                CommonUtils.showMesage("Please enter number only for estimated days!")
                            }
                        }
                        else {
                            CommonUtils.showMesage("Please enter a number between 1-100 for completed percentage!")
                        }
                    }
                    else {
                        CommonUtils.showMesage("Please fill the completed percentage.")
                    }
                }
                else {
                    CommonUtils.showMesage("Please fill the Due date.")
                }
            }
            else {
                CommonUtils.showMesage("Please fill the start date.")
            }
        }
        else {
            CommonUtils.showMesage("Please fill the Assignment name.")
        }
    }
    
    func assignInfo () {
        txtTaskName?.text = taskToEdit?.task_name
        txtStartDate?.text = taskToEdit?.start_date
        txtDueDate?.text = taskToEdit?.due_date
        txtEstimatedDays?.text = taskToEdit?.estimated_days
        txtCompletedPercentage?.text = taskToEdit?.completed_percentage
        txtNotes?.text = taskToEdit?.notes
        txtReminderDate?.text = taskToEdit?.reminder_date
        
        let reminderStatus = taskToEdit?.is_reminder_on
        
        if (reminderStatus)! {
            switchReminder?.isOn = true
            reminderView?.isHidden = false
        }
        else {
            switchReminder?.isOn = false
            reminderView?.isHidden = true
        }
        
        if (taskToEdit?.task_status == "1") {
            txtTaskStatus?.text = "Completed"
        }
        else if (taskToEdit?.task_status == "2") {
            txtTaskStatus?.text = "In Progress"
        }
        else if (taskToEdit?.task_status == "3") {
            txtTaskStatus?.text = "Not Started"
        }
    }
    
    func saveInfo () {
        var reminderStatus = true
        
        if (switchReminder?.isOn)! {
            reminderStatus = true
        }
        else {
            reminderStatus = false
        }
        let taskID : Int = self.getMaxAssignmentID() + 1
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let entity =  NSEntityDescription.entity(forEntityName: "Task",in: context)!
        let task = NSManagedObject(entity: entity,insertInto: context)
        task.setValue(txtTaskName?.text, forKey: "task_name")
        task.setValue(txtStartDate?.text, forKey: "start_date")
        task.setValue(txtDueDate?.text, forKey: "due_date")
        task.setValue(txtReminderDate?.text, forKey: "reminder_date")
        task.setValue(txtEstimatedDays?.text, forKey: "estimated_days")
        task.setValue(txtNotes?.text, forKey: "notes")
        task.setValue(txtCompletedPercentage?.text, forKey: "completed_percentage")
        task.setValue(String(taskID), forKey: "id")
        task.setValue(assignmentID, forKey: "assignment_id")
        task.setValue(CommonUtils.TaskStatus.NotStarted.rawValue, forKey: "task_status")
        
        if (switchReminder?.isOn)! {
            reminderStatus = true
            reminderIdentifier = ATMReminder.insertTaskReminder(store: eventStore, task: task as! Task)
        }
        else {
            reminderStatus = false
        }
        task.setValue(reminderStatus, forKey: "is_reminder_on")
        task.setValue(reminderIdentifier, forKey: "reminder_identifier")
        
        print(task)
        do {
            try context.save()
            self.dismiss(animated: true) {
                self.delegate?.updateDataAfterAddingTask()
            }
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    func updateInfo () {
        
        let taskID = taskToEdit?.id
        let taskReminderID = taskToEdit?.reminder_identifier
        // Deleting existing record
        ATMCoreDataHelper.deleteProfile(dataTable: CommonUtils.DataTables.Task.rawValue, withID: taskID!)
        ATMReminder.removeTaskReminder(store: eventStore, taskReminderID: taskReminderID!)
        
        // Saving Info
        var reminderStatus = true

        if (switchReminder?.isOn)! {
            reminderStatus = true
        }
        else {
            reminderStatus = false
        }
        
        // Status Info
        
        if (txtTaskStatus?.text == "Completed") {
            taskStatus = "1"
        }
        else if (txtTaskStatus?.text == "In Progress") {
            taskStatus = "2"
        }
        else if (txtTaskStatus?.text == "Not Started") {
            taskStatus = "3"
        }

        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

        let entity =  NSEntityDescription.entity(forEntityName: CommonUtils.DataTables.Task.rawValue, in: context)!
        
        let task = NSManagedObject(entity: entity,insertInto: context)
        task.setValue(txtTaskName?.text, forKey: "task_name")
        task.setValue(txtStartDate?.text, forKey: "start_date")
        task.setValue(txtDueDate?.text, forKey: "due_date")
        task.setValue(txtReminderDate?.text, forKey: "reminder_date")
        task.setValue(txtEstimatedDays?.text, forKey: "estimated_days")
        task.setValue(txtNotes?.text, forKey: "notes")
        task.setValue(txtCompletedPercentage?.text, forKey: "completed_percentage")
        task.setValue(taskID, forKey: "id")
        task.setValue(assignmentID, forKey: "assignment_id")
        task.setValue(taskStatus, forKey: "task_status")
        
        if (switchReminder?.isOn)! {
            reminderStatus = true
            reminderIdentifier = ATMReminder.insertTaskReminder(store: eventStore, task: task as! Task)
        }
        else {
            reminderStatus = false
        }
        task.setValue(reminderStatus, forKey: "is_reminder_on")
        task.setValue(reminderIdentifier, forKey: "reminder_identifier")
        
        print(task)
        
        do {
            try context.save()
            self.dismiss(animated: true) {
                self.delegate?.updateDataAfterAddingTask()
            }
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    func getMaxAssignmentID () -> Int{
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: CommonUtils.DataTables.Task.rawValue)
        fetchRequest.fetchLimit = 1
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "id", ascending: false)]
        
        var id = "0"
        let array : NSArray = (try! context.fetch(fetchRequest) as NSArray)
        if (array.count != 0) {
            let task:Task = array.object(at: 0) as! Task
            id = task.id!
        }
        return Int(id)!
    }
    
    //MARK: - UIPickerview Datasource
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return (arrayTaskStatus?.count)!
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
        return arrayTaskStatus!.object(at: row) as? String
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
        taskStatus = String(row + 1)
        txtTaskStatus?.text = arrayTaskStatus!.object(at: row) as? String
        if (row != 1) {
            viewPercentage?.isHidden = true
        }
        else {
            viewPercentage?.isHidden = false
        }
    }
    
    @IBAction func onChangedSwitchValue(_ sender: Any) {
        if (switchReminder?.isOn == true) {
            reminderView?.isHidden = false
        }
        else {
            reminderView?.isHidden = true
        }
    }
    func calculateRemaningdays () -> String{
        let dueDate = CommonUtils.convertDate(txtDueDate?.text)
        let diffInDays : Int = Calendar.current.dateComponents([.day], from: Date(), to: dueDate).day!
        return String(diffInDays)
    }
}
