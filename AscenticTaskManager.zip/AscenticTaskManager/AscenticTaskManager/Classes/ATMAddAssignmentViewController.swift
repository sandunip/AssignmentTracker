//
//  ATMAddAssignmentViewController.swift
//  AscenticTaskManager
//
//  Created by Sanduni Perera on 2/11/18.
//  Copyright © 2018 Sanduni Perera. All rights reserved.
//

import UIKit
import CoreData
import EventKit

protocol AddAssignmentDelegate: class {
    func updateDataAfterAddingAssignment()
}

class ATMAddAssignmentViewController: UIViewController,UIPickerViewDelegate, UIPickerViewDataSource {
    
    weak var delegate: AddAssignmentDelegate?
    
    @IBOutlet weak var txtAssignmentName:UITextField?
    @IBOutlet weak var txtModuleName:UITextField?
    @IBOutlet weak var txtLevel:UITextField?
    @IBOutlet weak var txtDueDate:UITextField?
    @IBOutlet weak var txtReminderDate:UITextField?
    @IBOutlet weak var reminderView:UIView?
    @IBOutlet weak var txtPercentageofModule:UITextField?
    @IBOutlet weak var txtMarkAwarded:UITextField?
    @IBOutlet weak var txtNotes:UITextView?
    @IBOutlet weak var switchReminder:UISwitch?
    
    @IBOutlet weak var lblNoofDaysRemaining:UILabel?
    
    @IBOutlet weak var btnSubmit:UIButton?
    var canEdit : Bool = true
    
    var assignments: NSArray = NSArray()
    var isUpdate: Bool = false
    var assignmentToEdit: Assignment?
    
    var eventIdentifier = ""
    var reminderIdentifier = ""
    
    let levelPicker:UIPickerView = UIPickerView()
    let dueDatePicker:UIDatePicker = UIDatePicker()
    let reminderDatePicker:UIDatePicker = UIDatePicker()
    
    var arrayLevel :NSArray?
    
    let eventStore = EKEventStore()

    override func viewDidLoad() {
        super.viewDidLoad()
        arrayLevel = ["4", "5", "6","7"]
        assignments = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        //txtReminderDate?.text = CommonUtils.convertDateToString(Calendar.current.date(byAdding: .day, value: 1, to: Date()))
        
        if (isUpdate) {
            self.assignInfo()
            lblNoofDaysRemaining?.text = self.calculateRemaningdays() + " days remaining"
        }
        else {
            lblNoofDaysRemaining?.text = ""
        }
        
        levelPicker.delegate = self
        levelPicker.dataSource = self
        txtLevel?.inputView = levelPicker
        
        reminderDatePicker.datePickerMode = UIDatePickerMode.date
        reminderDatePicker.minimumDate = Calendar.current.date(byAdding: .day, value: 1, to: Date())
        reminderDatePicker.addTarget(self, action: #selector(self.reminderDateChanged(_:)), for: UIControlEvents.valueChanged)
        txtReminderDate?.inputView = reminderDatePicker
        
        dueDatePicker.datePickerMode = UIDatePickerMode.date
        dueDatePicker.minimumDate = Calendar.current.date(byAdding: .day, value: 1, to: Date())
        dueDatePicker.addTarget(self, action: #selector(self.dateChanged(_:)), for: UIControlEvents.valueChanged)
        txtDueDate?.inputView = dueDatePicker
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ATMAddAssignmentViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
        
        if (!canEdit) {
            btnSubmit?.isHidden = true
        }
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    func assignInfo () {
        txtAssignmentName?.text = assignmentToEdit?.assignment_name
        txtModuleName?.text = assignmentToEdit?.module_name
        txtLevel?.text = assignmentToEdit?.level
        txtDueDate?.text = assignmentToEdit?.due_date
        txtMarkAwarded?.text = assignmentToEdit?.mark_awarded
        txtPercentageofModule?.text = assignmentToEdit?.value
        txtNotes?.text = assignmentToEdit?.notes
        txtReminderDate?.text = assignmentToEdit?.reminder_date
        
        let reminderStatus = assignmentToEdit?.is_reminder_on
        
        if (reminderStatus)! {
            switchReminder?.isOn = true
            reminderView?.isHidden = false
        }
        else {
            switchReminder?.isOn = false
            reminderView?.isHidden = true
        }
    }
    
    @objc func dateChanged(_ picker:UIDatePicker) {
        txtDueDate?.text = self.getFormattedDate(picker.date)
        lblNoofDaysRemaining?.text = self.calculateRemaningdays() + " days remaining"
        
        let reminderDate = CommonUtils.convertDate(txtDueDate?.text)
        txtReminderDate?.text = CommonUtils.convertDateToString(Calendar.current.date(byAdding: .day, value: -1, to: reminderDate))
    }
    
    @objc func reminderDateChanged(_ picker:UIDatePicker) {
        txtReminderDate?.text = self.getFormattedDate(picker.date)
    }
    
    func getFormattedDate (_ date:Date) -> String{
        let dateString:String = date.description
        return dateString.dateStringFromFormat("Y-M-d H-m-s Z", toFormat: "dd/MM/yyyy")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onClickDone(_ sender: Any) {
        validate()
    }
    
    @IBAction func onClickCancel(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    func validate () {
        if (txtAssignmentName?.text != "") {
            if (txtModuleName?.text != "") {
                if (txtDueDate?.text != "") {
                    if (CommonUtils.validateNumbersOverHundredof(textField: txtPercentageofModule!)) {
                        if (CommonUtils.validateNumbersOverHundredof(textField: txtMarkAwarded!)) {
                            
                            let reminderDate = CommonUtils.convertDate(txtReminderDate?.text)
                            let dueDate = CommonUtils.convertDate(txtDueDate?.text)
                            
                            if (reminderDate <= dueDate) {
                                if (isUpdate) {
                                    if (checkTaskDatesonAssignmentEditWith(assignmentId: (assignmentToEdit?.id)!)) {
                                        self.updateInfo()
                                    }else {
                                        CommonUtils.showMesage("The assignment date is smaller than the task dates, Please change the task dates first.")
                                    }
                                }
                                else {
                                    self.saveInfo()
                                }
                            }
                            else {
                                CommonUtils.showMesage("Reminder Date should be less or same date with due date!")
                            }
                            
                        }
                        else {
                            CommonUtils.showMesage("Please enter a number between 1-100 for awarded marks!")
                        }
                    }
                    else {
                        CommonUtils.showMesage("Please enter a number between 1-100 for module percentage!")
                    }
                }
                else {
                    CommonUtils.showMesage("Please fill the Due date.")
                }
            }
            else {
                CommonUtils.showMesage("Please fill the Module name.")
            }
        }
        else {
            CommonUtils.showMesage("Please fill the Assignment name.")
        }
    }
    
    func saveInfo () {
        var reminderStatus = true
        
        let assignmetnId : Int = self.getMaxAssignmentID() + 1
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let entity =  NSEntityDescription.entity(forEntityName: CommonUtils.DataTables.Assignment.rawValue,in: context)!
        let assignment = NSManagedObject(entity: entity,insertInto: context)
        assignment.setValue(txtAssignmentName?.text, forKey: "assignment_name")
        assignment.setValue(txtModuleName?.text, forKey: "module_name")
        assignment.setValue(txtLevel?.text, forKey: "level")
        assignment.setValue(txtDueDate?.text, forKey: "due_date")
        assignment.setValue(txtReminderDate?.text, forKey: "reminder_date")
        assignment.setValue(txtPercentageofModule?.text, forKey: "value")
        assignment.setValue(txtMarkAwarded?.text, forKey: "mark_awarded")
        assignment.setValue(txtNotes?.text, forKey: "notes")
        assignment.setValue(String(assignmetnId), forKey: "id")
        
        if (switchReminder?.isOn)! {
            reminderStatus = true
            eventIdentifier = ATMEvent.insertEvent(store: eventStore, assignment: assignment as! Assignment)
            reminderIdentifier = ATMReminder.insertReminder(store: eventStore, assignment: assignment as! Assignment)
        }
        else {
            reminderStatus = false
        }
        assignment.setValue(reminderStatus, forKey: "is_reminder_on")
        assignment.setValue(eventIdentifier, forKey: "event_identifier")
        assignment.setValue(reminderIdentifier, forKey: "reminder_identifier")
        
        print(assignment)
        do {
            try context.save()
            self.dismiss(animated: true) {
                self.delegate?.updateDataAfterAddingAssignment()
            }
            
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    func getMaxAssignmentID () -> Int{
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: CommonUtils.DataTables.Assignment.rawValue)
        fetchRequest.fetchLimit = 1
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "id", ascending: false)]
        
        var id = "0"
        let array : NSArray = (try! context.fetch(fetchRequest) as NSArray)
        if (array.count != 0) {
            let task:Assignment = array.object(at: 0) as! Assignment
            id = task.id!
            print("Max task id \(id)")
        }
        return Int(id)!
    }
    
    func updateInfo () {

        let eventID : String = assignmentToEdit?.event_identifier ?? ""
        let reminderID : String = assignmentToEdit?.reminder_identifier ?? ""
        let assignmentID : String = assignmentToEdit?.id ?? ""
        
        // Deleting existing record
        ATMCoreDataHelper.deleteProfile(dataTable: CommonUtils.DataTables.Assignment.rawValue, withID:(assignmentToEdit?.id!)!)
        ATMEvent.removeEvent(store: eventStore, assignmentEventID: eventID)
        ATMReminder.removeReminder(store: eventStore, assignmentReminderID: reminderID)
        
        // Saving Info
        var reminderStatus = true
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        let entity =  NSEntityDescription.entity(forEntityName: CommonUtils.DataTables.Assignment.rawValue,in: context)!
        let assignment = NSManagedObject(entity: entity,insertInto: context)
        assignment.setValue(txtAssignmentName?.text, forKey: "assignment_name")
        assignment.setValue(txtModuleName?.text, forKey: "module_name")
        assignment.setValue(txtLevel?.text, forKey: "level")
        assignment.setValue(txtDueDate?.text, forKey: "due_date")
        assignment.setValue(txtReminderDate?.text, forKey: "reminder_date")
        assignment.setValue(txtPercentageofModule?.text, forKey: "value")
        assignment.setValue(txtMarkAwarded?.text, forKey: "mark_awarded")
        assignment.setValue(txtNotes?.text, forKey: "notes")
        assignment.setValue(assignmentID, forKey: "id")
        
        if (switchReminder?.isOn)! {
            reminderStatus = true
            eventIdentifier = ATMEvent.insertEvent(store: eventStore, assignment: assignment as! Assignment)
            reminderIdentifier = ATMReminder.insertReminder(store: eventStore, assignment: assignment as! Assignment)
        }
        else {
            reminderStatus = false
        }
        
        assignment.setValue(reminderStatus, forKey: "is_reminder_on")
        assignment.setValue(eventIdentifier, forKey: "event_identifier")
        assignment.setValue(reminderIdentifier, forKey: "reminder_identifier")
        
        print(assignment)
        do {
            try context.save()
            self.dismiss(animated: true) {
                self.delegate?.updateDataAfterAddingAssignment()
            }
        } catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
    }
    
    //MARK: - UIPickerview Datasource
    func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return (arrayLevel?.count)!
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
        return arrayLevel!.object(at: row) as? String
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
        txtLevel?.text = arrayLevel!.object(at: row) as? String
    }
    
    @IBAction func onChangedSwitchValue(_ sender: Any) {
        if (switchReminder?.isOn == true) {
            reminderView?.isHidden = false
        }
        else {
            reminderView?.isHidden = true
        }
    }
    
    // Warning the user if he tries to backdate the assignment (edit), but task due dates are longer
    func checkTaskDatesonAssignmentEditWith (assignmentId : String) -> Bool {
        var boolStatus = true
        let taskArray = ATMCoreDataHelper.getTasksWith(assignmentId: assignmentId)
        
        for task in taskArray {
            let taskDate = CommonUtils.convertDate((task as! Task).due_date)
            let newAssignmentDate = CommonUtils.convertDate(txtDueDate?.text)
            if (taskDate > newAssignmentDate) {
                boolStatus = false
                break
            }
        }
        return boolStatus
    }
    
    func calculateRemaningdays () -> String{
        let dueDate = CommonUtils.convertDate(txtDueDate?.text)
        let diffInDays : Int = Calendar.current.dateComponents([.day], from: Date(), to: dueDate).day!
        return String(diffInDays)
    }
}
