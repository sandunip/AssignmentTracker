//
//  ATMPreviewViewController.swift
//  AscenticTaskManager
//
//  Created by Sanduni Perera on 2/11/18.
//  Copyright © 2018 Sanduni Perera. All rights reserved.
//

import UIKit
import UICircularProgressRing

class ATMPreviewViewController: UIViewController {
    
    @IBOutlet weak var lblAssignmentName:UILabel?
    @IBOutlet weak var lblModuleName:UILabel?
    @IBOutlet weak var lblDueDate:UILabel?
    @IBOutlet weak var lblPercentageofModule:UILabel?
    @IBOutlet weak var lblMarkAwarded:UILabel?
    @IBOutlet weak var txtNotes:UITextView?
    
    @IBOutlet weak var lblTasksComplted:UILabel?
    @IBOutlet weak var lblTasksInProgress:UILabel?
    @IBOutlet weak var lblTasksNotStarted:UILabel?
    
    @IBOutlet weak var lblRemainingDays:UILabel?
    
    @IBOutlet weak var viewProgress:UICircularProgressRingView?
    
    var assignment: Assignment?
    
    var arrayInProgressTasks: NSArray?
    var arrayNotStartedTasks: NSArray?
    var arrayCompletedTasks: NSArray?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        arrayInProgressTasks = ATMCoreDataHelper.getTasksWith(status:CommonUtils.TaskStatus.InProgress.rawValue, assignmentId: (assignment?.id)!)
        arrayNotStartedTasks = ATMCoreDataHelper.getTasksWith(status:CommonUtils.TaskStatus.NotStarted.rawValue, assignmentId: (assignment?.id)!)
        arrayCompletedTasks = ATMCoreDataHelper.getTasksWith(status:CommonUtils.TaskStatus.Completed.rawValue, assignmentId: (assignment?.id)!)
        
        self.assignInfo()
        self.calculatePercentage()
    }
    
    func assignInfo () {
        
        let tasksCompleted = arrayCompletedTasks?.count ?? 0
        let tasksInProgress = arrayInProgressTasks?.count ?? 0
        let tasksNotStarted = arrayNotStartedTasks?.count ?? 0
        
        lblTasksComplted?.text = String(tasksCompleted)
        lblTasksInProgress?.text = String(tasksInProgress)
        lblTasksNotStarted?.text = String(tasksNotStarted)
        
        lblAssignmentName?.text = assignment?.assignment_name
        lblModuleName?.text = assignment?.module_name
        lblDueDate?.text = assignment?.due_date
        lblMarkAwarded?.text = assignment?.mark_awarded
        lblPercentageofModule?.text = assignment?.value
        txtNotes?.text = assignment?.notes
        
        lblRemainingDays?.text = calculateRemaningdays()
    }
    
    func calculatePercentage () {
        var percentage : Int = 0
        
        for obj in arrayInProgressTasks! {
            let task = obj as! Task
            percentage += Int(task.completed_percentage!)!
        }
        
        for obj in arrayCompletedTasks! {
            percentage += 100
        }
        
        let taskCount : Int = (arrayInProgressTasks?.count)! + (arrayCompletedTasks?.count)! + (arrayNotStartedTasks?.count)!
        
        let finalPercentage = CGFloat(percentage/taskCount)
        
        self.viewProgress?.animationStyle = kCAMediaTimingFunctionLinear
        self.viewProgress?.setProgress(value: finalPercentage, animationDuration: 5.0) {
            print("Set the percentage!")
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onClickDone(_ sender: Any) {
        self.dismiss(animated: false, completion: nil)
    }
    
    func calculateRemaningdays () -> String{
        let dueDate = CommonUtils.convertDate(lblDueDate?.text)
        let diffInDays : Int = Calendar.current.dateComponents([.day], from: Date(), to: dueDate).day!
        var txtToDisplay = ""
        
        if (diffInDays > 0) {
            txtToDisplay = "ONLY " + String(diffInDays) + " DAYS ARE REMAINING TO COMPLETE THE ASSIGNMENT!"
        }
        else {
            txtToDisplay = "ASSIGNMENT EXPIRED " + String(diffInDays) + " AGO"
        }
        return txtToDisplay
    }

}
