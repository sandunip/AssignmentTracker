//
//  ATMMasterViewController.swift
//  AscenticTaskManager
//
//  Created by Sanduni Perera on 2/14/18.
//  Copyright © 2018 Sanduni Perera. All rights reserved.
//

import UIKit
import EventKit
import CoreData
import GTProgressBar
import MZFormSheetPresentationController

protocol AssignmentSelectionDelegate: class {
    func assignmentSelected(_ assignment: Assignment)
}

class ATMAssignmentCell: UITableViewCell{
    @IBOutlet weak var lblAssignment:UILabel?
    @IBOutlet weak var lblDueDate:UILabel?
    @IBOutlet weak var btnDelete:UIButton?
    @IBOutlet weak var btnEdit:UIButton?
}

class ATMMasterViewController: UITableViewController, AddAssignmentDelegate {
    
    weak var delegate: AssignmentSelectionDelegate?
    var arrayAssignments : NSArray = NSArray()
    
    let eventStore = EKEventStore()
    
    var currentSelection = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.tableFooterView = UIView()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        NotificationCenter.default.addObserver(self, selector: #selector(ATMMasterViewController.deleteAll), name:NSNotification.Name(rawValue: "DELETE"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(ATMMasterViewController.addAll), name:NSNotification.Name(rawValue: "ADD"), object: nil)
        arrayAssignments = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        if (arrayAssignments.count > 0) {
        currentSelection = arrayAssignments.count - 1
        }
        self.tableView.reloadData()
    }
    
    @objc func deleteAll () {
        // Delete all reminders, events and assignments
        ATMReminder.removeAllReminders(store: eventStore)
        ATMEvent.removeAllEvents(store: eventStore)
        ATMCoreDataHelper.deleteAllData(entityName: CommonUtils.DataTables.Assignment.rawValue)
        
        // Get info and refresh assignments table view again
        arrayAssignments = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        print(arrayAssignments)
        if (arrayAssignments.count > 0) {
            currentSelection = arrayAssignments.count - 1
        }
        self.tableView.reloadData()
    }
    
    @objc func addAll () {
        arrayAssignments = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        if (arrayAssignments.count > 0) {
            currentSelection = arrayAssignments.count - 1
        }
        self.tableView.reloadData()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayAssignments.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell:ATMAssignmentCell?
        cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ATMAssignmentCell
        
        cell?.btnDelete?.addTarget(self, action: #selector(ATMMasterViewController.onClickDeleteAssignment(_:)), for: .touchUpInside)
        cell?.btnEdit?.addTarget(self, action: #selector(ATMMasterViewController.onClickEditAssignment(_:)), for: .touchUpInside)
        
        let assignment : Assignment = arrayAssignments.object(at: (indexPath.row)) as! Assignment
        
        cell?.lblAssignment?.text = assignment.assignment_name
        cell?.lblDueDate?.text = assignment.due_date
        
        let backgroundView:UIView = UIView(frame: cell!.bounds)
        backgroundView.backgroundColor = UIColor.getAppThemeColor()
        cell?.selectedBackgroundView = backgroundView
        
        if (indexPath.row == currentSelection) {
            cell?.backgroundColor = UIColor.getAppThemeColor()
        }
        else {
            cell?.backgroundColor = UIColor.getMasterTableBackgroundColor()
        }
        
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 94
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedAssignment = arrayAssignments[indexPath.row] as! Assignment
//        delegate?.assignmentSelected(selectedAssignment)
//        if let detailViewController = delegate as? ATMDetailViewController,
//            let detailNavigationController = detailViewController.navigationController {
//            splitViewController?.showDetailViewController(detailNavigationController, sender: nil)
//        }
        if (arrayAssignments.count > 0) {
            currentSelection = indexPath.row
        }
        self.tableView?.reloadData()
        NotificationCenter.default.post(name: Notification.Name(rawValue: "ChangeAssignment"), object: selectedAssignment)
    }
    
    //MARK: - UITableview Button click actions
    
    @objc func onClickDeleteAssignment(_ sender : UIButton) {
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tableView)
        let indexPath = self.tableView?.indexPathForRow(at: buttonPosition)
        
        let assignment : Assignment = arrayAssignments.object(at: (indexPath?.row)!) as! Assignment
        let assignmentID = assignment.id
        
        // Remove assignment , event and reminder
        ATMReminder.removeReminder(store: eventStore, assignmentReminderID: assignment.reminder_identifier!)
        ATMEvent.removeEvent(store: eventStore, assignmentEventID: assignment.event_identifier!)
        ATMCoreDataHelper.deleteProfile(dataTable: CommonUtils.DataTables.Assignment.rawValue, withID:assignmentID!)
        
        // Remove task and reminder
        ATMReminder.removeTaskRemindersofSelectedAssignment(store: eventStore, assignmentID: assignmentID!)
        ATMCoreDataHelper.deleteAllDataTasks(assignmentID: assignmentID!)
        
        arrayAssignments = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        if (arrayAssignments.count > 0) {
            currentSelection = arrayAssignments.count - 1
        }
        self.tableView?.reloadData()
        
        NotificationCenter.default.post(name: Notification.Name(rawValue: "RefreshTaskTable"), object: nil)
    }
    
    @objc func onClickEditAssignment(_ sender:UIButton) {
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tableView)
        let indexPath = self.tableView?.indexPathForRow(at: buttonPosition)
        
        let assignment : Assignment = arrayAssignments.object(at: (indexPath?.row)!) as! Assignment
        
        // Navigate to edit the assignment
        let vc:ATMAddAssignmentViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMAddAssignmentViewController") as! ATMAddAssignmentViewController
        vc.delegate = self
        vc.assignmentToEdit = assignment
        vc.isUpdate = true
        let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
        formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
        self.present(formSheetController, animated: false, completion: nil)
    }
    
    // MARK: - Add Assignment Delegate
    
    func updateDataAfterAddingAssignment() {
        arrayAssignments = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        if (arrayAssignments.count > 0) {
            currentSelection = arrayAssignments.count - 1
        }
        self.tableView?.reloadData()
    }
    
}
