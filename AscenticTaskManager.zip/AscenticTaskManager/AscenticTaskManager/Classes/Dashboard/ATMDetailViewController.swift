//
//  ATMDetailViewController.swift
//  AscenticTaskManager
//
//  Created by Sanduni Perera on 2/14/18.
//  Copyright © 2018 Sanduni Perera. All rights reserved.
//

import UIKit
import EventKit
import CoreData
import GTProgressBar
import MZFormSheetPresentationController

class ATMTaskCell: UITableViewCell {
    @IBOutlet weak var lblTask:UILabel?
    @IBOutlet weak var lblDueDate:UILabel?
    @IBOutlet weak var lblCompletedPercentage:UILabel?
    @IBOutlet weak var imageViewExpired:UIImageView?
    @IBOutlet weak var viewProgress:GTProgressBar?
    @IBOutlet weak var btnDelete:UIButton?
    @IBOutlet weak var btnEdit:UIButton?
}

class ATMDetailViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, AddAssignmentDelegate, AddTaskDelegate, AssignmentSelectionDelegate {
    
    @IBOutlet weak var btnAddAssignment:UIButton?
    

    var arrayInProgressTasks : NSArray = NSArray()
    var arrayNotStartedTasks : NSArray = NSArray()

    @IBOutlet weak var tableViewInProgress:UITableView?
    @IBOutlet weak var tableViewNotStarted:UITableView?
    
    @IBOutlet weak var lblOverDueTasks:UILabel?
    
    var currentAssignment: Assignment?
    var currentAssignmentId: String = "0"
    
    var expiredActivitiesCount: Int = 0
    
    let eventStore = EKEventStore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let vc :ATMMasterViewController = ATMMasterViewController()
        vc.delegate = self
        
        ATMCoreDataHelper.getAllRemindersAndUpdateAssignmentReminderStatus(store: eventStore)
        ATMCoreDataHelper.getAllRemindersAndUpdateTaskReminderStatus(store: eventStore)

        let arrayAssignment:NSArray = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        if (arrayAssignment.count != 0) {
            currentAssignment = arrayAssignment.lastObject as? Assignment
            print(currentAssignment)
            currentAssignmentId = (currentAssignment?.id)!
        }
        
        tableViewInProgress?.tableFooterView = UIView()
        tableViewNotStarted?.tableFooterView = UIView()
        
        if (expiredActivitiesCount == 0) {
            lblOverDueTasks?.text = ""
        }
        else {
            lblOverDueTasks?.text = String(expiredActivitiesCount)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        expiredActivitiesCount = getTaskInfo().count + getAssignmentInfo().count
        NotificationCenter.default.addObserver(self, selector: #selector(markCurrentSelection), name:NSNotification.Name(rawValue: "ChangeAssignment"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshTablesAfterDeletingAssignment), name:NSNotification.Name(rawValue: "RefreshTaskTable"), object: nil)
        self.reloadTableviews()
    }
    
    @objc func markCurrentSelection (_ notification: NSNotification) {
        let object:Assignment = notification.object as! Assignment
        currentAssignment = object
        currentAssignmentId = object.id!
        
        self.reloadTableviews()
    }
    
    @objc func refreshTablesAfterDeletingAssignment (_ notification: NSNotification) {
        let arrayAssignment:NSArray = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        if (arrayAssignment.count != 0) {
            currentAssignment = arrayAssignment.lastObject as? Assignment
            currentAssignmentId = (currentAssignment?.id)!
        }
        
        self.reloadTableviews()
    }
    
    // Mark - Button click events
    @IBAction func onClickAddAssignment(_ sender: Any) {
        let vc:ATMAddAssignmentViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMAddAssignmentViewController") as! ATMAddAssignmentViewController
        vc.delegate = self
        let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
        formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
        self.present(formSheetController, animated: false, completion: nil)
    }
    
    @IBAction func onClickAddTask(_ sender: Any) {
        let arrayAssignment:NSArray = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        if (arrayAssignment.count != 0){
            let assignmentDueDate = CommonUtils.convertDate(currentAssignment?.due_date)
            
            if (assignmentDueDate > Date()) {
                let vc:ATMAddTaskViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMAddTaskViewController") as! ATMAddTaskViewController
                vc.delegate = self as AddTaskDelegate
                vc.assignmentID = currentAssignmentId
                vc.assignment = currentAssignment
                let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
                formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
                self.present(formSheetController, animated: false, completion: nil)
            }
            else {
                CommonUtils.showMesage("The selected assignment is expired. Please update the assignment or add a new assignment!")
            }
        }
        else {
            CommonUtils.showMesage("Please add at least one assignment to add a task!")
        }
    }
    
    @IBAction func onClickPreview(_ sender: Any) {
        if (currentAssignmentId != "") {
            let array = ATMCoreDataHelper.getTasksWith(assignmentId: currentAssignmentId)
            if (array.count != 0){
                let vc:ATMPreviewViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMPreviewViewController") as! ATMPreviewViewController
                vc.assignment = currentAssignment
                let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
                formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
                self.present(formSheetController, animated: false, completion: nil)
            }
            else {
                CommonUtils.showMesage("No tasks have been added!")
            }
        }
        else {
            CommonUtils.showMesage("No Assignment is selected!")
        }
    }
    
    @IBAction func onClickCompletedTasks(_ sender: Any) {
        let arrayAssignment:NSArray = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        if (arrayAssignment.count != 0){
            let arrayCompletedTasks:NSArray  = ATMCoreDataHelper.getTasksWith(status:CommonUtils.TaskStatus.Completed.rawValue, assignmentId: currentAssignmentId)
            if (arrayCompletedTasks.count != 0){
                let vc:ATMCompletedTasksViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMCompletedTasksViewController") as! ATMCompletedTasksViewController
                vc.currentAssignmentId = currentAssignmentId
                let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
                formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
                self.present(formSheetController, animated: false, completion: nil)
            }
            else {
                CommonUtils.showMesage("No Completed tasks to show.")
            }
        }
        else {
            CommonUtils.showMesage("No Assignments have been added.")
        }
    }
    
    @IBAction func onClickDeleteAllAssignments(_ sender: Any) {
        showConfirmationAlert("Are you sure you want delete all the Assignments?")
    }
    
    func showConfirmationAlert(_ message:String){
        let alert:UIAlertController = UIAlertController(title: "Ascentic Task Manager", message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default, handler:{ [weak self](UIAlertAction) in
            // Remove task reminders and tasks
            ATMReminder.removeTaskAllReminders(store: (self?.eventStore)!)
            ATMCoreDataHelper.deleteAllData(entityName: CommonUtils.DataTables.Task.rawValue)
            
            // Get info again and load tableviews
            self?.reloadTableviews()
            
            // Delete assignment related data in master view controller
            NotificationCenter.default.post(name: Notification.Name(rawValue: "DELETE"), object: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler:{ [weak self](UIAlertAction) in
            self?.dismiss(animated: true, completion: nil)
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    // Added assignment , update current selection and notify master view controller to reload master table view
    func updateDataAfterAddingAssignment() {
        let arrayAssignment:NSArray = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        currentAssignment = arrayAssignment.lastObject as? Assignment
        currentAssignmentId = (currentAssignment?.id)!
        NotificationCenter.default.post(name: Notification.Name(rawValue: "ADD"), object: nil)
    }
    
    @IBAction func onClickDeleteAllTasks(_ sender: Any) {
        ATMCoreDataHelper.deleteAllDataTasks(assignmentID: currentAssignmentId)
        
        self.reloadTableviews()
    }
    
    @IBAction func onClickExpiredTasks(_ sender: Any) {
        if (expiredActivitiesCount > 0) {
            let vc:ATMExpiredActivitiesViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMExpiredActivitiesViewController") as! ATMExpiredActivitiesViewController
            let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
            formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
            self.present(formSheetController, animated: false, completion: nil)
        }
        else {
            CommonUtils.showMesage("No Overdue tasks to show!")
        }
    }
    
    //MARK: - UITableView Datasource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (tableView == tableViewInProgress) {
            return arrayInProgressTasks.count
        }
        else {
            return arrayNotStartedTasks.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        if (tableView == tableViewInProgress) {
            var cell:ATMTaskCell?
            cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ATMTaskCell
            
            let task : Task = arrayInProgressTasks.object(at: (indexPath.row)) as! Task
            
            cell?.lblTask?.text = task.task_name?.uppercased()
            cell?.lblDueDate?.text = task.due_date
            
            cell?.btnDelete?.addTarget(self, action: #selector(ATMDetailViewController.onClickDeleteAssignmentInProgress(_:)), for: .touchUpInside)
            cell?.btnEdit?.addTarget(self, action: #selector(ATMDetailViewController.onClickEditAssignmentInProgress(_:)), for: .touchUpInside)
            
            let percentage = task.completed_percentage ?? "0"
            let completedPercentage: Float = Float(percentage)!/100
            cell?.viewProgress?.progress = CGFloat(completedPercentage)
            
            cell?.lblCompletedPercentage?.text = percentage + "%"
            
            let remainingDays = calculateRemaningdays(dueDate: CommonUtils.convertDate(task.due_date))
            if (remainingDays < 1) {
                cell?.imageViewExpired?.isHidden = false
            }
            else {
                cell?.imageViewExpired?.isHidden = true
            }
            
            return cell!
        }
        else {
            var cell:ATMTaskCell?
            cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? ATMTaskCell
            
            cell?.btnDelete?.addTarget(self, action: #selector(ATMDetailViewController.onClickDeleteAssignmentNotStarted(_:)), for: .touchUpInside)
            cell?.btnEdit?.addTarget(self, action: #selector(ATMDetailViewController.onClickEditAssignmentNotStarted(_:)), for: .touchUpInside)
            
            let task : Task = arrayNotStartedTasks.object(at: (indexPath.row)) as! Task
            
            cell?.lblTask?.text = task.task_name?.uppercased()
            cell?.lblDueDate?.text = task.due_date
            
            let remainingDays = calculateRemaningdays(dueDate: CommonUtils.convertDate(task.due_date))
            if (remainingDays < 1) {
                cell?.imageViewExpired?.isHidden = false
            }
            else {
                cell?.imageViewExpired?.isHidden = true
            }
            
            return cell!
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if (tableView == tableViewInProgress) {
            return 128
        }
        else {
            return 98
        }
    }
    
    func calculateRemaningdays (dueDate : Date) -> Int{
        let diffInDays : Int = Calendar.current.dateComponents([.day], from: Date(), to: dueDate).day!
        return diffInDays
    }
    
    //MARK: - UITableview Button click actions
    
    @objc func onClickDeleteAssignmentNotStarted(_ sender : UIButton) {
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tableViewNotStarted)
        let indexPath = self.tableViewNotStarted?.indexPathForRow(at: buttonPosition)
        
        let task : Task = arrayNotStartedTasks.object(at: (indexPath?.row)!) as! Task
        
        let taskId = task.id
        let taskReminder = task.reminder_identifier

        ATMReminder.removeTaskReminder(store: eventStore, taskReminderID: taskReminder!)
        ATMCoreDataHelper.deleteProfile(dataTable: CommonUtils.DataTables.Task.rawValue, withID:taskId!)
        
        arrayNotStartedTasks = ATMCoreDataHelper.getTasksWith(status:CommonUtils.TaskStatus.NotStarted.rawValue, assignmentId: currentAssignmentId)
        self.tableViewNotStarted?.reloadData()
    }
    
    @objc func onClickEditAssignmentNotStarted(_ sender:UIButton) {
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tableViewNotStarted)
        let indexPath = self.tableViewNotStarted?.indexPathForRow(at: buttonPosition)
        
        let task : Task = arrayNotStartedTasks.object(at: (indexPath?.row)!) as! Task
        
        // Navigate to edit the task
        let vc:ATMAddTaskViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMAddTaskViewController") as! ATMAddTaskViewController
        vc.delegate = self as AddTaskDelegate
        vc.taskToEdit = task
        vc.isUpdate = true
        vc.assignmentID = currentAssignmentId
        vc.assignment = currentAssignment
        let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
        formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
        self.present(formSheetController, animated: false, completion: nil)
    }
    
    @objc func onClickDeleteAssignmentInProgress(_ sender : UIButton) {
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tableViewInProgress)
        let indexPath = self.tableViewInProgress?.indexPathForRow(at: buttonPosition)
        
        let task : Task = arrayInProgressTasks.object(at: (indexPath?.row)!) as! Task
        
        let taskId = task.id
        let taskReminder = task.reminder_identifier
        
        ATMReminder.removeTaskReminder(store: eventStore, taskReminderID: taskReminder!)
        ATMCoreDataHelper.deleteProfile(dataTable: CommonUtils.DataTables.Task.rawValue, withID:taskId!)
        
        arrayInProgressTasks = ATMCoreDataHelper.getTasksWith(status:CommonUtils.TaskStatus.InProgress.rawValue, assignmentId: currentAssignmentId)
        self.tableViewInProgress?.reloadData()
    }
    
    @objc func onClickEditAssignmentInProgress(_ sender:UIButton) {
        let buttonPosition:CGPoint = sender.convert(CGPoint.zero, to:self.tableViewInProgress)
        let indexPath = self.tableViewInProgress?.indexPathForRow(at: buttonPosition)
        
        let task : Task = arrayInProgressTasks.object(at: (indexPath?.row)!) as! Task
        
        // Navigate to edit the assignment
        let vc:ATMAddTaskViewController = self.storyboard!.instantiateViewController(withIdentifier: "ATMAddTaskViewController") as! ATMAddTaskViewController
        vc.delegate = self
        vc.taskToEdit = task
        vc.isUpdate = true
        vc.assignmentID = currentAssignmentId
        vc.assignment = currentAssignment
        let formSheetController = MZFormSheetPresentationViewController(contentViewController: vc)
        formSheetController.presentationController?.contentViewSize = CGSize.init(width: 800, height: 700)
        self.present(formSheetController, animated: false, completion: nil)
    }
    
    // Mark - Class delegates
    
    func updateDataAfterAddingTask() {
        self.reloadTableviews()
    }
    
    func assignmentSelected(_ assignment: Assignment) {
        currentAssignment = assignment
        
        self.reloadTableviews()
    }
    
    func reloadTableviews () {
        arrayInProgressTasks = ATMCoreDataHelper.getTasksWith(status:CommonUtils.TaskStatus.InProgress.rawValue, assignmentId: currentAssignmentId)
        arrayNotStartedTasks = ATMCoreDataHelper.getTasksWith(status:CommonUtils.TaskStatus.NotStarted.rawValue, assignmentId: currentAssignmentId)
        
        tableViewInProgress?.reloadData()
        tableViewNotStarted?.reloadData()
    }
    
    // Mark - Caluculate expired tasks/ assignments
    
    func getTaskInfo () -> NSMutableArray{
        let arrayExpiredTasks : NSMutableArray = NSMutableArray()
        let arrayTasks = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Task.rawValue)
        
        for task in arrayTasks {
            let taskDueDate = CommonUtils.convertDate((task as! Task).due_date)
            let taskStatus = (task as! Task).task_status
            if ((taskDueDate < Date()) && (taskStatus != "1")) {
                arrayExpiredTasks.add(task)
            }
        }
        return arrayExpiredTasks
    }
    
    func getAssignmentInfo () -> NSMutableArray{
        let arrayExpiredAssignments : NSMutableArray = NSMutableArray()
        let arrayAssignments = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        
        for assignment in arrayAssignments {
            let incompletedTasksArray = ATMCoreDataHelper.getIncompletedTasksForAssignment(withAssignmentId: (assignment as! Assignment).id!)
            let assignmentDueDate = CommonUtils.convertDate((assignment as! Assignment).due_date)
            if (assignmentDueDate < Date() && incompletedTasksArray.count > 0) {
                arrayExpiredAssignments.add(assignment)
            }
        }
        return arrayExpiredAssignments
    }
    
    

}
