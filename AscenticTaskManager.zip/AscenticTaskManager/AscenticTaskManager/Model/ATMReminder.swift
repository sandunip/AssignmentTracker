//
//  ATMReminder.swift
//  AscenticTaskManager
//
//  Created by Sanduni Perera on 2/17/18.
//  Copyright © 2018 Sanduni Perera. All rights reserved.
//

import UIKit
import EventKit
import CoreData

class ATMReminder: NSObject {
    
    //MARK: - Add  reminder - Assignment
    
    static func insertReminder (store: EKEventStore, assignment:Assignment) -> String{
        var reminderIdentifier = ""
        let reminder = EKReminder(eventStore: store)
        
        reminder.title = assignment.assignment_name
        reminder.calendar = store.defaultCalendarForNewReminders()
        let alarmist : EKAlarm = EKAlarm()
        alarmist.relativeOffset = -0
        reminder.addAlarm(alarmist)
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let dueDateComponents = appDelegate.dateComponentFromNSDate(date: CommonUtils.convertDate(assignment.reminder_date) as Date)
        
        reminder.dueDateComponents  = dueDateComponents as DateComponents
        
        do {
            try store.save(reminder,
                           commit: true)
            print("saved with \(reminder.calendarItemIdentifier)")
            reminderIdentifier = reminder.calendarItemIdentifier
        } catch let error {
            print("Reminder failed with error \(error.localizedDescription)")
        }
        return reminderIdentifier
    }
    
    //MARK : Remove reminder - Assignment
    
    static func removeReminder(store: EKEventStore, assignmentReminderID:String) {
        let selectedReminder = store.calendarItem(withIdentifier: assignmentReminderID)
        print(selectedReminder ?? "none")
        
        do {
            if (selectedReminder != nil) {
                try store.remove(selectedReminder as! EKReminder, commit: true)
            }
        } catch let error {
            print("Reminder delete failed with error \(error.localizedDescription)")
        }
    }
    
    // MARK : Remove all reminders - Assignment
    
    static func removeAllReminders (store: EKEventStore) {
        // Get assignments
        let array = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        
        for assignment in array {
            let selectedReminder = store.calendarItem(withIdentifier: (assignment as! Assignment).reminder_identifier!)
            print(selectedReminder ?? "none")
            
            do {
                if (selectedReminder != nil) {
                    try store.remove(selectedReminder as! EKReminder, commit: true)
                }
            } catch let error {
                print("Reminder delete failed with error \(error.localizedDescription)")
            }
        }
    }
    
    //MARK: - Add  reminder - Task
    
    static func insertTaskReminder (store: EKEventStore, task:Task) -> String{
        var reminderIdentifier = ""
        let reminder = EKReminder(eventStore: store)
        
        reminder.title = task.task_name
        reminder.calendar = store.defaultCalendarForNewReminders()
        let alarmist : EKAlarm = EKAlarm()
        alarmist.relativeOffset = -0
        reminder.addAlarm(alarmist)
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let dueDateComponents = appDelegate.dateComponentFromNSDate(date: CommonUtils.convertDate(task.reminder_date) as Date)
        
        reminder.dueDateComponents  = dueDateComponents as DateComponents
        
        do {
            try store.save(reminder,
                           commit: true)
            print("saved with \(reminder.calendarItemIdentifier)")
            reminderIdentifier = reminder.calendarItemIdentifier
        } catch let error {
            print("Reminder failed with error \(error.localizedDescription)")
        }
        return reminderIdentifier
    }
    
    //MARK : Remove reminder - Task
    
    static func removeTaskReminder(store: EKEventStore, taskReminderID:String) {
        let selectedReminder = store.calendarItem(withIdentifier: taskReminderID)
        print(selectedReminder ?? "none")
        
        do {
            if (selectedReminder != nil) {
                try store.remove(selectedReminder as! EKReminder, commit: true)
            }
        } catch let error {
            print("Reminder delete failed with error \(error.localizedDescription)")
        }
    }
    
    // MARK : Remove all reminders - Task
    
    static func removeTaskAllReminders (store: EKEventStore) {
        // Get assignments
        let array = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Task.rawValue)
        
        for task in array {
            let selectedReminder = store.calendarItem(withIdentifier: (task as! Task).reminder_identifier!)
            print(selectedReminder ?? "none")
            
            do {
                if (selectedReminder != nil) {
                    try store.remove(selectedReminder as! EKReminder, commit: true)
                }
            } catch let error {
                print("Reminder delete failed with error \(error.localizedDescription)")
            }
        }
    }
    
    // MARK : Remove all reminders - Task
    
    static func removeTaskRemindersofSelectedAssignment (store: EKEventStore, assignmentID:String) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: CommonUtils.DataTables.Task.rawValue)
        fetchRequest.predicate = NSPredicate.init(format: "assignment_id ==\(assignmentID)")
        
        if let result = try? context.fetch(fetchRequest) {
            for object in result {
                let selectedReminder = store.calendarItem(withIdentifier: (object as! Task).reminder_identifier!)
                print(selectedReminder ?? "none")
                
                do {
                    if (selectedReminder != nil) {
                        try store.remove(selectedReminder as! EKReminder, commit: true)
                    }
                } catch let error {
                    print("Reminder delete failed with error \(error.localizedDescription)")
                }
            }
        }
    }
    
    
}
