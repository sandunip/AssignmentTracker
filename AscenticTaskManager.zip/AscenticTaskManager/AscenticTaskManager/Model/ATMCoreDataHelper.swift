//
//  ATMCoreDataHelper.swift
//  AscenticTaskManager
//
//  Created by Sanduni Perera on 2/11/18.
//  Copyright © 2018 Sanduni Perera. All rights reserved.
//

import UIKit
import CoreData
import EventKit

class ATMCoreDataHelper: NSObject {
    
    static func deleteAllData(entityName : String) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: entityName)
        fetchRequest.returnsObjectsAsFaults = false
        
        do {
            let results = try context.fetch(fetchRequest as! NSFetchRequest<NSFetchRequestResult>)
            for managedObject in results
            {
                let managedObjectData:NSManagedObject = managedObject as! NSManagedObject
                context.delete(managedObjectData)
                do {
                    try context.save()
                    print("saved!")
                } catch let error as NSError  {
                    print("Could not save \(error), \(error.userInfo)")
                }
            }
        } catch let error as NSError {
            print("Detele all data in Assignment error : \(error) \(error.userInfo)")
        }
    }
    
    static func deleteAllDataTasks(assignmentID : String) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: CommonUtils.DataTables.Task.rawValue)
        fetchRequest.predicate = NSPredicate.init(format: "assignment_id ==\(assignmentID)")
        
        if let result = try? context.fetch(fetchRequest) {
            for object in result {
                context.delete(object)
            }
            do {
                try context.save()
                print("saved!")
            } catch let error as NSError  {
                print("Could not save \(error), \(error.userInfo)")
            }
        }
    }
    
    static func getInfo (dataTable : String) -> NSArray{
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: dataTable)
        fetchRequest.returnsObjectsAsFaults = false
        var array : NSArray = []
        do {
            array = try context.fetch(fetchRequest) as NSArray
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return array
    }
    
    static func getAssignment (withId : String) -> Assignment{
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: CommonUtils.DataTables.Assignment.rawValue)
        fetchRequest.predicate = NSPredicate.init(format: "id ==\(withId)")
        fetchRequest.returnsObjectsAsFaults = false
        var array : NSArray = []
        do {
            array = try context.fetch(fetchRequest) as NSArray
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return array.firstObject as! Assignment
    }
    
    static func deleteProfile(dataTable : String, withID: String) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: dataTable)
        fetchRequest.predicate = NSPredicate.init(format: "id ==\(withID)")
        
        if let result = try? context.fetch(fetchRequest) {
            for object in result {
                context.delete(object)
            }
            do {
                try context.save()
                print("saved!")
            } catch let error as NSError  {
                print("Could not save \(error), \(error.userInfo)")
            }
        }
    }
    
    static func deleteRecordWithMatchingIdentifier(dataTable : String, dataField : String, withID: String) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: dataTable)
        fetchRequest.predicate = NSPredicate.init(format: "\(dataField) ==\(withID)")
        
        if let result = try? context.fetch(fetchRequest) {
            for object in result {
                context.delete(object)
            }
            do {
                try context.save()
                print("saved!")
            } catch let error as NSError  {
                print("Could not save \(error), \(error.userInfo)")
            }
        }
    }
    
    static func getTasksWith(status: String, assignmentId : String) -> NSArray{
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: CommonUtils.DataTables.Task.rawValue)
        fetchRequest.predicate = NSPredicate.init(format: "task_status = \(status) AND assignment_id = \(assignmentId)")
        fetchRequest.returnsObjectsAsFaults = false
        var array : NSArray = []
        do {
            array = try context.fetch(fetchRequest) as NSArray
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return array
    }
    
    static func getTasksWith(assignmentId : String) -> NSArray{
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: CommonUtils.DataTables.Task.rawValue)
        fetchRequest.predicate = NSPredicate.init(format: "assignment_id = \(assignmentId)")
        fetchRequest.returnsObjectsAsFaults = false
        var array : NSArray = []
        do {
            array = try context.fetch(fetchRequest) as NSArray
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return array
    }
    
    static func getIncompletedTasksForAssignment(withAssignmentId : String) -> NSArray{
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: CommonUtils.DataTables.Task.rawValue)
        fetchRequest.predicate = NSPredicate.init(format: "assignment_id = \(withAssignmentId) AND task_status != 1")
        fetchRequest.returnsObjectsAsFaults = false
        var array : NSArray = []
        do {
            array = try context.fetch(fetchRequest) as NSArray
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        return array
    }
    
    static func getAllRemindersAndUpdateAssignmentReminderStatus (store: EKEventStore) {
        // Get info and cross check with reminders
        let arrayAssignments = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        for assignment in arrayAssignments {
            let selectedReminder = store.calendarItem(withIdentifier: (assignment as! Assignment).reminder_identifier!)
            
            if (selectedReminder == nil) {
                let assignmentToUpdate = assignment as! Assignment
                print(assignmentToUpdate as! Assignment)
                
                let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
                
                let assignmentID = assignmentToUpdate.id!
                let assignmentName = assignmentToUpdate.assignment_name!
                let dueDate = assignmentToUpdate.due_date!
                
                let eventIdentifier = assignmentToUpdate.event_identifier!
                let level = assignmentToUpdate.level
                let markAwarded = assignmentToUpdate.mark_awarded
                
                let moduleName = assignmentToUpdate.module_name!
                let notes = assignmentToUpdate.notes
                let reminderDate = assignmentToUpdate.reminder_date
                
                let reminderIdentifier = assignmentToUpdate.reminder_identifier!
                let value = assignmentToUpdate.value

                ATMCoreDataHelper.deleteRecordWithMatchingIdentifier(dataTable: CommonUtils.DataTables.Assignment.rawValue, dataField: "id", withID: assignmentID)
                
                let entity =  NSEntityDescription.entity(forEntityName: CommonUtils.DataTables.Assignment.rawValue,in: context)!
                let newAssignment = NSManagedObject(entity: entity,insertInto: context)
                
                newAssignment.setValue(assignmentName, forKey: "assignment_name")
                newAssignment.setValue(dueDate, forKey: "due_date")
                newAssignment.setValue(eventIdentifier, forKey: "event_identifier")
                newAssignment.setValue(level, forKey: "level")
                newAssignment.setValue(markAwarded, forKey: "mark_awarded")
                newAssignment.setValue(moduleName, forKey: "module_name")
                newAssignment.setValue(notes, forKey: "notes")
                newAssignment.setValue(reminderDate, forKey: "reminder_date")
                newAssignment.setValue(reminderIdentifier, forKey: "reminder_identifier")
                newAssignment.setValue(value, forKey: "value")
                newAssignment.setValue(false, forKey: "is_reminder_on")
                newAssignment.setValue(assignmentID, forKey: "id")
                
                print(newAssignment)
                do {
                    try context.save()
                    print("saved")
                    
                } catch let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
                }
            }
        }
    }
    
    static func getAllRemindersAndUpdateTaskReminderStatus (store: EKEventStore) {
        
        // Get info and cross check with reminders
        let arrayTasks = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Task.rawValue)
        for task in arrayTasks {
            let selectedReminder = store.calendarItem(withIdentifier: (task as! Task).reminder_identifier!)
            
            if (selectedReminder == nil) {
                let taskToUpdate = task as! Task
                
                let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

                let taskID = taskToUpdate.id!
                let taskAssignmentID = taskToUpdate.assignment_id!
                let completedPercentage = taskToUpdate.completed_percentage!
                let dueDate = taskToUpdate.due_date!
                let estimatedDays = taskToUpdate.estimated_days!
                let eventIdentifier = taskToUpdate.event_identifier
                let notes = taskToUpdate.notes
                let reminderDate = taskToUpdate.reminder_date
                let reminderIdentifier = taskToUpdate.reminder_identifier!
                let startDate = taskToUpdate.start_date
                let taskName = taskToUpdate.task_name!
                let taskStatus = taskToUpdate.task_status

                ATMCoreDataHelper.deleteRecordWithMatchingIdentifier(dataTable: CommonUtils.DataTables.Task.rawValue, dataField: "id", withID: taskID)

                let entity =  NSEntityDescription.entity(forEntityName: CommonUtils.DataTables.Task.rawValue,in: context)!
                let newTask = NSManagedObject(entity: entity,insertInto: context)

                newTask.setValue(taskID, forKey: "id")
                newTask.setValue(taskAssignmentID, forKey: "assignment_id")
                newTask.setValue(completedPercentage, forKey: "completed_percentage")
                newTask.setValue(dueDate, forKey: "due_date")
                newTask.setValue(estimatedDays, forKey: "estimated_days")
                newTask.setValue(eventIdentifier, forKey: "event_identifier")
                newTask.setValue(notes, forKey: "notes")
                newTask.setValue(reminderIdentifier, forKey: "reminder_date")
                newTask.setValue(reminderDate, forKey: "reminder_identifier")
                newTask.setValue(startDate, forKey: "start_date")
                newTask.setValue(taskName, forKey: "task_name")
                newTask.setValue(taskStatus, forKey: "task_status")
                newTask.setValue(false, forKey: "is_reminder_on")

                print(newTask)
                do {
                    try context.save()
                    print("saved")

                } catch let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
                }
            }
        }
    }
}
