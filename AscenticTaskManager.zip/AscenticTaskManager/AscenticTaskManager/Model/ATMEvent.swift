//
//  ATMEvent.swift
//  AscenticTaskManager
//
//  Created by Sanduni Perera on 2/17/18.
//  Copyright © 2018 Sanduni Perera. All rights reserved.
//

import UIKit
import EventKit

class ATMEvent: NSObject {
    
    //MARK: - Add  calander event
    
    static func insertEvent(store: EKEventStore, assignment:Assignment) -> String {
        
        var eventIdentifier = ""
        let calendars = store.calendars(for: .event)
        
        for calendar in calendars {
            
            // Create Event
            let event = EKEvent(eventStore: store)
            event.calendar = calendar
            
            event.title = assignment.assignment_name
            event.startDate = Calendar.current.date(byAdding: .day, value: -1, to: Date())!
            event.endDate = CommonUtils.convertDate(assignment.reminder_date)
            
            do {
                let result = try store.save(event, span: EKSpan.thisEvent, commit: true)
                eventIdentifier = event.eventIdentifier
            } catch let error as NSError {
                print("Could not save. \(error), \(error.userInfo)")
            }
        }
        return eventIdentifier
    }
    
    //MARK : Remove event
    
    static func removeEvent(store: EKEventStore, assignmentEventID:String) {
        let selectedEvent = store.event(withIdentifier: assignmentEventID)
        print(selectedEvent ?? "none")
        
        do {
            if (selectedEvent != nil) {
                try store.remove(selectedEvent!, span: EKSpan.thisEvent, commit: true)
            }
        } catch let error {
            print("Reminder delete failed with error \(error.localizedDescription)")
        }
    }
    
    // MARK : Remove all events
    
    static func removeAllEvents (store: EKEventStore) {
        // Get assignments
        let array = ATMCoreDataHelper.getInfo(dataTable: CommonUtils.DataTables.Assignment.rawValue)
        
        for assignment in array {
            let selectedEvent = store.event(withIdentifier: (assignment as! Assignment).event_identifier!)
            print(selectedEvent ?? "none")
            
            do {
                if (selectedEvent != nil) {
                    try store.remove(selectedEvent!, span: EKSpan.thisEvent, commit: true)
                }
            } catch let error {
                print("Reminder delete failed with error \(error.localizedDescription)")
            }
        }
    }
    
}
